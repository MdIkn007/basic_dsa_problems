# Basic-DSA

Python solutions for the 20 problems listed in the Basic DSA Problems (Units I–III) assignment.

## Files
Each numbered `.py` file solves one assignment question. The programs use Python's standard library only.

## Run a solution
From this folder, run any file with Python, for example:

```bash
python 01_print_1_to_n_recursion.py
```

On Windows, if `python` is not recognized, try:

```bash
py 01_print_1_to_n_recursion.py
```

## Notes
- Inputs are entered in the terminal when prompted.
- Binary-search solutions expect sorted input arrays.
- `03_fibonacci.py` uses the straightforward recursive method for learning; it is slow for large N.
- `07_string_subsequences.py` includes the empty subsequence.
- `09_string_permutations.py` prints unique permutations, even if the input has repeated characters.
- `20_remove_duplicates_linked_list.py` expects sorted input, as specified in the assignment.

Review and understand each solution, test it, and be prepared to explain the logic during assessment.
