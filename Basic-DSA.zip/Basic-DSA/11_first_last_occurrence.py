"""Find first and last occurrence of a target in a sorted array."""

def first_occurrence(arr, target):
    left, right, answer = 0, len(arr) - 1, -1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] >= target:
            if arr[mid] == target:
                answer = mid
            right = mid - 1
        else:
            left = mid + 1
    return answer

def last_occurrence(arr, target):
    left, right, answer = 0, len(arr) - 1, -1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] <= target:
            if arr[mid] == target:
                answer = mid
            left = mid + 1
        else:
            right = mid - 1
    return answer

if __name__ == "__main__":
    arr = list(map(int, input("Enter sorted array elements: ").split()))
    target = int(input("Enter target: "))
    print("First occurrence:", first_occurrence(arr, target))
    print("Last occurrence:", last_occurrence(arr, target))
