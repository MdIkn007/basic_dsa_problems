"""Find floor (largest <= target) and ceil (smallest >= target)."""

def floor_value(arr, target):
    left, right, answer = 0, len(arr) - 1, None
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] <= target:
            answer = arr[mid]
            left = mid + 1
        else:
            right = mid - 1
    return answer

def ceil_value(arr, target):
    left, right, answer = 0, len(arr) - 1, None
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] >= target:
            answer = arr[mid]
            right = mid - 1
        else:
            left = mid + 1
    return answer

if __name__ == "__main__":
    arr = list(map(int, input("Enter sorted array elements: ").split()))
    target = int(input("Enter target: "))
    print("Floor:", floor_value(arr, target))
    print("Ceil:", ceil_value(arr, target))
