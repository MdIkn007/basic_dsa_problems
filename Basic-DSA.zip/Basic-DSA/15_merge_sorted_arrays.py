"""Merge two sorted arrays into one sorted array."""

def merge_sorted(arr1, arr2):
    i = j = 0
    merged = []
    while i < len(arr1) and j < len(arr2):
        if arr1[i] <= arr2[j]:
            merged.append(arr1[i])
            i += 1
        else:
            merged.append(arr2[j])
            j += 1
    merged.extend(arr1[i:])
    merged.extend(arr2[j:])
    return merged

if __name__ == "__main__":
    arr1 = list(map(int, input("Enter first sorted array: ").split()))
    arr2 = list(map(int, input("Enter second sorted array: ").split()))
    print("Merged array:", merge_sorted(arr1, arr2))
