"""Print all subsequences of a string (including the empty string)."""

def subsequences(text, index=0, current=""):
    if index == len(text):
        print(repr(current))
        return
    subsequences(text, index + 1, current)
    subsequences(text, index + 1, current + text[index])

if __name__ == "__main__":
    text = input("Enter a string: ")
    subsequences(text)
