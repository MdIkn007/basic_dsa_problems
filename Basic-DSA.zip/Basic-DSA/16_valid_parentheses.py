"""Check whether parentheses/brackets/braces are balanced."""

def is_valid(text):
    pairs = {")": "(", "]": "[", "}": "{"}
    stack = []
    for char in text:
        if char in "([{":
            stack.append(char)
        elif char in pairs:
            if not stack or stack.pop() != pairs[char]:
                return False
    return not stack

if __name__ == "__main__":
    text = input("Enter parentheses string: ")
    print("Valid" if is_valid(text) else "Invalid")
