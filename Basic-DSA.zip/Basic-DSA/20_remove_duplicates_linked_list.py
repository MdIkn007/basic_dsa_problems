"""Remove duplicates from a sorted singly linked list."""

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        node = Node(data)
        if self.head is None:
            self.head = node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = node

    def remove_duplicates(self):
        current = self.head
        while current and current.next:
            if current.data == current.next.data:
                current.next = current.next.next
            else:
                current = current.next

    def to_list(self):
        values = []
        current = self.head
        while current:
            values.append(current.data)
            current = current.next
        return values

if __name__ == "__main__":
    values = list(map(int, input("Enter sorted linked-list values: ").split()))
    linked_list = LinkedList()
    for value in values:
        linked_list.append(value)
    linked_list.remove_duplicates()
    print("After removing duplicates:", linked_list.to_list())
