"""Find the next greater element to the right for each array element."""

def next_greater_elements(arr):
    result = [-1] * len(arr)
    stack = []  # Stores indices whose next greater value is not known yet.
    for i, value in enumerate(arr):
        while stack and arr[stack[-1]] < value:
            result[stack.pop()] = value
        stack.append(i)
    return result

if __name__ == "__main__":
    arr = list(map(int, input("Enter array elements: ").split()))
    print("Next greater elements:", next_greater_elements(arr))
