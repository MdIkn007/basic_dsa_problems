"""Stack supporting push, pop, top, and get_min in O(1) time."""

class MinStack:
    def __init__(self):
        self.stack = []
        self.min_stack = []

    def push(self, value):
        self.stack.append(value)
        if not self.min_stack or value <= self.min_stack[-1]:
            self.min_stack.append(value)

    def pop(self):
        if not self.stack:
            raise IndexError("pop from empty stack")
        value = self.stack.pop()
        if value == self.min_stack[-1]:
            self.min_stack.pop()
        return value

    def top(self):
        if not self.stack:
            raise IndexError("top from empty stack")
        return self.stack[-1]

    def get_min(self):
        if not self.min_stack:
            raise IndexError("minimum of empty stack")
        return self.min_stack[-1]

if __name__ == "__main__":
    stack = MinStack()
    print("Commands: push N | pop | top | min | quit")
    while True:
        command = input("> ").strip().lower().split()
        if not command:
            continue
        if command[0] == "push" and len(command) == 2:
            stack.push(int(command[1]))
        elif command[0] == "pop":
            try:
                print(stack.pop())
            except IndexError as error:
                print(error)
        elif command[0] == "top":
            try:
                print(stack.top())
            except IndexError as error:
                print(error)
        elif command[0] == "min":
            try:
                print(stack.get_min())
            except IndexError as error:
                print(error)
        elif command[0] == "quit":
            break
        else:
            print("Unknown command or invalid input.")
