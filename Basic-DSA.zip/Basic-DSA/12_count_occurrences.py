"""Count occurrences of a target in a sorted array using binary search."""

def lower_bound(arr, target):
    left, right = 0, len(arr)
    while left < right:
        mid = (left + right) // 2
        if arr[mid] < target:
            left = mid + 1
        else:
            right = mid
    return left

def upper_bound(arr, target):
    left, right = 0, len(arr)
    while left < right:
        mid = (left + right) // 2
        if arr[mid] <= target:
            left = mid + 1
        else:
            right = mid
    return left

def count_occurrences(arr, target):
    return upper_bound(arr, target) - lower_bound(arr, target)

if __name__ == "__main__":
    arr = list(map(int, input("Enter sorted array elements: ").split()))
    target = int(input("Enter target: "))
    print("Occurrences:", count_occurrences(arr, target))
