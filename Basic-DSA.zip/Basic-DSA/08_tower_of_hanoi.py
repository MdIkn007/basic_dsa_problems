"""Solve Tower of Hanoi and print each move."""

def tower_of_hanoi(n, source="A", auxiliary="B", destination="C"):
    if n <= 0:
        return
    tower_of_hanoi(n - 1, source, destination, auxiliary)
    print(f"Move disk {n} from {source} to {destination}")
    tower_of_hanoi(n - 1, auxiliary, source, destination)

if __name__ == "__main__":
    n = int(input("Enter number of disks: "))
    if n < 0:
        print("Number of disks cannot be negative.")
    else:
        tower_of_hanoi(n)
