"""Check whether an array is sorted in non-decreasing order using recursion."""

def is_sorted(arr, index=1):
    if len(arr) <= 1 or index >= len(arr):
        return True
    if arr[index - 1] > arr[index]:
        return False
    return is_sorted(arr, index + 1)

if __name__ == "__main__":
    arr = list(map(int, input("Enter array elements separated by spaces: ").split()))
    print("Sorted" if is_sorted(arr) else "Not sorted")
