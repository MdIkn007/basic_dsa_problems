"""Generate all unique permutations of a string."""

def permutations(text, index=0):
    chars = list(text)
    results = set()

    def backtrack(pos):
        if pos == len(chars):
            results.add("".join(chars))
            return
        for i in range(pos, len(chars)):
            chars[pos], chars[i] = chars[i], chars[pos]
            backtrack(pos + 1)
            chars[pos], chars[i] = chars[i], chars[pos]

    backtrack(index)
    for item in sorted(results):
        print(repr(item))

if __name__ == "__main__":
    permutations(input("Enter a string: "))
